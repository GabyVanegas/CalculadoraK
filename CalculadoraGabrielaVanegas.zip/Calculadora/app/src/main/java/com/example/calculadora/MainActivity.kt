package com.example.calculadora

import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var btnIgual: Button
    lateinit var btnBorrar: Button
    var operacion: Int = 0
    var num: Double = 0.0
    lateinit var tvx1: TextView
    lateinit var tvx2: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        this.requestedOrientation =
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        tvx1 = findViewById(R.id.txv1)
        tvx2 = findViewById(R.id.tvx2)
        btnIgual = findViewById(R.id.btnIgual)
        btnBorrar = findViewById(R.id.btnC)

        btnIgual.setOnClickListener(){
            var num2 = tvx2.text.toString().toDouble()
            var resultado = 0.0
            when(operacion){
                1-> resultado = num + num2
                2-> resultado = num - num2
                3-> resultado = num / num2
                4-> resultado = num * num2
            }
            tvx2.setText(resultado.toString())
            tvx1.setText("")
        }

        btnBorrar.setOnClickListener(){
            tvx1.setText("")
            tvx2.setText("")
            operacion = 0
        }
    }

    fun PresionarDig(view: View){
        var num2: String = tvx2.text.toString()

        when(view.id){
            R.id.btnCero -> tvx2.setText(num2 + "0")
            R.id.btnUno -> tvx2.setText(num2 + "1")
            R.id.btnDos -> tvx2.setText(num2 + "2")
            R.id.btnTres -> tvx2.setText(num2 + "3")
            R.id.btnCuatro -> tvx2.setText(num2 + "4")
            R.id.btnCinco -> tvx2.setText(num2 + "5")
            R.id.btnSeis -> tvx2.setText(num2 + "6")
            R.id.btnSiete -> tvx2.setText(num2 + "7")
            R.id.btnOcho -> tvx2.setText(num2 + "8")
            R.id.btnNueve -> tvx2.setText(num2 + "9")
            R.id.btnPunto -> tvx2.setText(num2 + ".")
        }
    }

    fun funOperacion(view: View){
        var num2: String = tvx2.text.toString()
        num = num2.toString().toDouble()
        tvx2.setText("")

        when(view.id){
            R.id.btnsuma ->{
                tvx1.setText(num2 + "+")
                operacion = 1
            }
            R.id.btnResta ->{
                tvx1.setText(num2 + "-")
                operacion = 2
            }
            R.id.btnDiv ->{
                tvx1.setText(num2 + "/")
                operacion = 3

            }
            R.id.btnMultiplicacion ->{
                tvx1.setText(num2 + "*")
                operacion = 4
            }
        }
    }
}